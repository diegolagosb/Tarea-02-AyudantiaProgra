package Paquetes;

public class Main {

    
    public static void main(String[] args) {
       Ejecutar s=new Ejecutar();
       s.inciar();
    }
    
}
