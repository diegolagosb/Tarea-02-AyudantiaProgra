package Paquetes;


public class Polera {
    
    private String talla;
    private String material;
    private boolean estampado;
    private int serial;
    
    public Polera(String Talla, String Material, boolean Estampado,int Serial){
        talla=Talla;
        material=Material;
        estampado=Estampado;
        serial=Serial;
    }

    public String getTalla() {
        return talla;
    }

    public String getMaterial() {
        return material;
    }

    public boolean getEstampado() {
        return estampado;
    }

    public int getSerial() {
        return serial;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public void setEstampado(boolean estampado) {
        this.estampado = estampado;
    }

    public void setSerial(int serial) {
        this.serial = serial;
    }
    
    
    
}
